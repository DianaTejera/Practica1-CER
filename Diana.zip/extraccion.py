import cloudscraper
import re


def obtener_cambio():
    scraper = cloudscraper.create_scraper(delay=10, browser={'custom':'ScraperBot/1.0', })
    url = 'https://es.investing.com/currencies/eur-usd'
    resp = scraper.get(url)

    if resp.status_code == 200:
        html = resp.text
        pattern = 'data-test="instrument-price-last">(\d+\,\d+)</span>'
        match = re.search(pattern, html)
        if match:
            return match.group(1)
        else:
            return "N/A"
    else:
        print('code',resp.status_code)
        return "Could not connect to es.investing.com"





