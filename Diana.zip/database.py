#devuelve True si se registro
#devuelve False si ya existia
def registro(email, username, clave):
    return True


#devuelve True si se logueo
#devuelve False si no esta registrado
def login(username, clave):
    return True


def bbdd_medialocal(usuario):
    # guardar que ha pedido una media mas
    return str(0)


def bbdd_mediaremoto(usuario):
    # guardar que ha pedido una media mas
    return str(1)


def obtener_numero_medias_local(usuario):
    return str(9)


def obtener_numero_medias_remoto(usuario):
    return str(4)